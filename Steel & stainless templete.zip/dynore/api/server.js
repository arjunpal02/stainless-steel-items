var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var cors = require('cors');
var mysql = require('mysql');
const jwt = require('jsonwebtoken');
var multer = require('multer');
var nodemailer = require('nodemailer');
const smtpTransport = require('nodemailer-smtp-transport');
app.use(bodyParser.json());
app.use(cors());
app.use(bodyParser.urlencoded({
extended: true
}));
// default route
app.get('/', function (req, res) {
return res.send({ error: true, message: 'hello' })
});
// connection configurations
var dbConn = mysql.createConnection({
host: 'localhost',
user: 'root',
password: '',
database:'dynore'
});
// connect to database
dbConn.connect(); 
// Retrieve all users 
app.get('/users', function (req, res) {
dbConn.query('SELECT * FROM users', function (error, results, fields) {
if (error) throw error;
return res.send({ error: false, data: results, message: 'users list.' });
});
});
// posts api
app.get('/posts', function (req, res) {
  dbConn.query('SELECT * FROM posts', function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'posts list.' });
  });
  });
  // categories api
app.get('/categories', function (req, res) {
  dbConn.query('SELECT * FROM categories', function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'categories list.' });
  });
  });
  // pages api
app.get('/pages', function (req, res) {
  dbConn.query('SELECT * FROM pages', function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'pages list.' });
  });
  });
  // portfolios api
app.get('/portfolios', function (req, res) {
  dbConn.query('SELECT * FROM portfolios', function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'portfolios list.' });
  });
  });
// Retrieve user with id 
app.get('/user/:id', function (req, res) {
let user_id = req.params.id;
if (!user_id) {
return res.status(400).send({ error: true, message: 'Please provide user_id' });
}
dbConn.query('SELECT * FROM users where id=?', user_id, function (error, results, fields) {
if (error) throw error;
return res.send({ error: false, data: results[0], message: 'users list.' });
});
});
// Retrieve post with id 
app.get('/post/:id', function (req, res) {
  let post_id = req.params.id;
  if (!post_id) {
  return res.status(400).send({ error: true, message: 'Please provide post_id' });
  }
  dbConn.query('SELECT * FROM posts where id=?', post_id, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results[0], message: 'posts list.' });
  });
  });
  // Retrieve category with id 
app.get('/category/:id', function (req, res) {
  let category_id = req.params.id;
  if (!category_id) {
  return res.status(400).send({ error: true, message: 'Please provide category_id' });
  }
  dbConn.query('SELECT * FROM categories where id=?', category_id, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results[0], message: 'categories list.' });
  });
  });
  // Retrieve page with id 
app.get('/page/:id', function (req, res) {
  let page_id = req.params.id;
  if (!page_id) {
  return res.status(400).send({ error: true, message: 'Please provide page_id' });
  }
  dbConn.query('SELECT * FROM pages where id=?', page_id, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results[0], message: 'pages list.' });
  });
  });
  // Retrieve portfolio with id 
app.get('/portfolio/:id', function (req, res) {
  let portfolio_id = req.params.id;
  if (!portfolio_id) {
  return res.status(400).send({ error: true, message: 'Please provide portfolio_id' });
  }
  dbConn.query('SELECT * FROM portfolios where id=?', portfolio_id, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results[0], message: 'portfolios list.' });
  });
  });
// Add a new user  
app.post('/user', function (req, res) {
let email = req.body.email;
let user = req.body;
if (!email) {
return res.status(400).send({ error:true, message: 'Please provide user' });
}
dbConn.query('SELECT * FROM users where email=?', email, function (error, results, fields) {
    if (error) throw error;
    if(results[0]){
    return res.send({ error: false, data: results[0], message: 'users list.',userExist:true });
    }
    else{
        var sql = "INSERT INTO users (name,email,password,address,state,gender,phone,role_id) VALUES ('"+user.name+"', '"+user.email+"','"+user.password+"','"+user.address+"','"+user.state+"','"+user.gender+"','"+user.phone+"',1)";
dbConn.query(sql, function (error, results, fields) {
if (error) throw error;
return res.send({ error: false, data: results, message: 'New user has been created successfully.' });
});
    }
    });

});
//add new query
app.post('/addnewquery', function (req, res) {
  let enquiry = req.body;
  
          var sql = "INSERT INTO enquiry (name,email,mobile,country,massage) VALUES ('"+enquiry.name+"', '"+enquiry.email+"','"+enquiry.mobile+"','"+enquiry.country+"','"+enquiry.massage+"')";
  dbConn.query(sql, function (error, results, fields) {
  if (error) throw error;
  // var transporter = nodemailer.createTransport(smtpTransport({
  //   host: 'smtp.gmail.com',
  //   port: 587,
  //   secure: false,
  //   requireTLS: true,
  //   auth: {
  //       user: 'sarahjhonson0402@gmail.com',
  //       pass: 'sarah0402@'
  //   }
  // }));
  
  // var mailOptions = {
  //   from: 'sarahjhonson0402@gmail.com',
  //   to: 'sarahjhonson0402@gmail.com',
  //   subject: 'Enquiry form Data',
  //   text: 'That was easy!'
  // };
  
  // transporter.sendMail(mailOptions, function(error, info){
  //   if (error) {
  //     console.log(error);
  //   } else {
  //     console.log('Email sent: ' + info.response);
  //   }
  // });

  return res.send({ error: false, data: results, message: 'New query has been created successfully.' });
  });
      
      });


      //add new booking
app.post('/addnewbooking', function (req, res) {
  let safaribooking = req.body;
  
          var sql = "INSERT INTO safaribooking (booking_date,vehicle,timing,name,mobile,email) VALUES ('"+safaribooking.booking_date+"','"+safaribooking.vehicle+"', '"+safaribooking.timing+"','"+safaribooking.name+"','"+safaribooking.mobile+"','"+safaribooking.email+"')";
  dbConn.query(sql, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'New booking has been created successfully.' });
  });
      
      });

//add new category
app.post('/addnewcategory', function (req, res) {
  let category = req.body;
  
          var sql = "INSERT INTO categories (name,description) VALUES ('"+category.name+"', '"+category.description+"')";
  dbConn.query(sql, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'New category has been created successfully.' });
  });
      
      });
      //add new page
app.post('/addnewpage', function (req, res) {
  let page = req.body;
  
          var sql = "INSERT INTO pages (title,slug,description) VALUES ('"+page.title+"', '"+page.slug+"', '"+page.description+"')";
  dbConn.query(sql, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'New page has been created successfully.' });
  });
      
      });
      //add new portfolio
app.post('/addnewportfolio', function (req, res) {
  let portfolio = req.body;
  
          var sql = "INSERT INTO portfolios (title,description,image) VALUES ('"+portfolio.title+"', '"+portfolio.description+"', '"+portfolio.image+"')";
  dbConn.query(sql, function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'New portfolio has been created successfully.' });
  });
      
      });
  
  
//  Update user with id
app.put('/user', function (req, res) {
let user_id = req.body.user_id;
let user = req.body.user;
if (!user_id || !user) {
return res.status(400).send({ error: user, message: 'Please provide user and user_id' });
}
dbConn.query("UPDATE users SET  ? WHERE id = ?", [user, user_id], function (error, results, fields) {
if (error) throw error;
return res.send({ error: false, data: results, message: 'user has been updated successfully.' });
});
});
//  Update post with id
app.put('/post', function (req, res) {
  let post_id = req.body.post_id;
  let post = req.body.post;
  if (!post_id || !post) {
  return res.status(400).send({ error: post, message: 'Please provide post and post_id' });
  }
  dbConn.query("UPDATE posts SET  ? WHERE id = ?", [post, post_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'post has been updated successfully.' });
  });
  });
  //  Update category with id
app.put('/category', function (req, res) {
  let category_id = req.body.category_id;
  let category = req.body.category;
  if (!category_id || !category) {
  return res.status(400).send({ error: category, message: 'Please provide category and category_id' });
  }
  dbConn.query("UPDATE categories SET  ? WHERE id = ?", [category, category_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'category has been updated successfully.' });
  });
  });
  //  Update page with id
app.put('/page', function (req, res) {
  let page_id = req.body.page_id;
  let page = req.body.page;
  if (!page_id || !page) {
  return res.status(400).send({ error: page, message: 'Please provide page and page_id' });
  }
  dbConn.query("UPDATE pages SET  ? WHERE id = ?", [page, page_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'page has been updated successfully.' });
  });
  });
  //  Update portfolio with id
app.put('/portfolio', function (req, res) {
  let portfolio_id = req.body.portfolio_id;
  let portfolio = req.body.portfolio;
  if (!portfolio_id || !portfolio) {
  return res.status(400).send({ error: portfolio, message: 'Please provide portfolio and portfolio_id' });
  }
  dbConn.query("UPDATE portfolios SET  ? WHERE id = ?", [portfolio, portfolio_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'portfolio has been updated successfully.' });
  });
  });
//  Delete user
app.delete('/user', function (req, res) {
let user_id = req.body.user_id;
if (!user_id) {
return res.status(400).send({ error: true, message: 'Please provide user_id' });
}
dbConn.query('DELETE FROM users WHERE id = ?', [user_id], function (error, results, fields) {
if (error) throw error;
return res.send({ error: false, data: results, message: 'User has been updated successfully.' });
});
}); 
//  Delete posts
app.delete('/post', function (req, res) {
  let post_id = req.body.post_id;
  if (!post_id) {
  return res.status(400).send({ error: true, message: 'Please provide post_id' });
  }
  dbConn.query('DELETE FROM posts WHERE id = ?', [post_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'post has been updated successfully.' });
  });
  }); 
  //  Delete categories
app.delete('/category', function (req, res) {
  let category_id = req.body.category_id;
  if (!category_id) {
  return res.status(400).send({ error: true, message: 'Please provide category_id' });
  }
  dbConn.query('DELETE FROM categories WHERE id = ?', [category_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'category has been deleted successfully.' });
  });
  }); 
  //  Delete pages
app.delete('/page', function (req, res) {
  let page_id = req.body.page_id;
  if (!page_id) {
  return res.status(400).send({ error: true, message: 'Please provide page_id' });
  }
  dbConn.query('DELETE FROM pages WHERE id = ?', [page_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'page has been deleted successfully.' });
  });
  }); 
  //  Delete portfolios
app.delete('/portfolio', function (req, res) {
  let portfolio_id = req.body.portfolio_id;
  if (!portfolio_id) {
  return res.status(400).send({ error: true, message: 'Please provide portfolio_id' });
  }
  dbConn.query('DELETE FROM portfolios WHERE id = ?', [portfolio_id], function (error, results, fields) {
  if (error) throw error;
  return res.send({ error: false, data: results, message: 'portfolio has been deleted successfully.' });
  });
  }); 
//  login user
app.post('/login', function (req, res) {
    let email = req.body.email;
    let password = req.body.password
    if (!email) {
    return res.status(400).send({ error: true, message: 'Please provide user_id' });
    }
    dbConn.query('select * from  users WHERE email = ? and password =?', [email,password], function (error, results, fields) {
    if (error) throw error;let  token ;
    if(results.length>0){
    token = jwt.sign(
        {email },
       '123456789abcdef',
        {
          expiresIn: "1h",
        }
      );
    }
    return res.send({ error: false, data: results, token: token });
    });
    });

    //
    

// set port
app.listen(3000, function () {
console.log('Node app is running on port 3000');
});
module.exports = app;